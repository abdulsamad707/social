<link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>

 <a href="{{url("reset_password/".$token)}}">Reset Password</a>
   
      